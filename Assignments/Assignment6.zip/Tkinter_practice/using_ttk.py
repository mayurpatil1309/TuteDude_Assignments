import tkinter as tk
from tkinter import font as fnt
from tkinter import ttk

window = tk.Tk()
window.title("My Application")
window.minsize(400, 400)

#custom_font = fnt.Font(family="Times New Roman", size=20, weight="bold", slant="italic")
custom_font = fnt.Font(family="Times New Roman", size=20, weight="bold")

#label = tk.Label(text="Hello World", font=("Times New Roman", 20))
label = ttk.Label(text="Hello World", font=custom_font,padding=15)
label.pack()

label["text"] = "Hello World! This is My Application"

def button_clicked():
    input_text=user_input.get()
    label["text"] = input_text


user_input = ttk.Entry(width=50)
user_input.pack()



#Button
button = ttk.Button(text="Click", command=button_clicked)
button.pack()

quit_button = ttk.Button(text="Quit", command=window.destroy)
quit_button.pack(pady=10)

sep = ttk.Separator(orient="horizontal")
sep.pack(fill="x")

text_box=tk.Text(height=5, width=50)
text_box.pack(pady=10)
text_box.focus()
text_box.insert("1.0", "Enter your characters!")


"""
#for disabling anything
text_box["state"] = 'disabled'

def enable_text_box():
    text_box["state"] = 'normal'

enable_button = ttk.Button(text="Enable", command=enable_text_box)
enable_button.pack()
"""

def text_function():
    text_data=text_box.get("1.0", "end")
    print(text_data)

text_box_button = ttk.Button(text="Text", command=text_function)
text_box_button.pack()

#check_option = tk.IntVar()
check_option = tk.StringVar()
def check_option_task():
    print(check_option.get())

check_button = ttk.Checkbutton(text="Agree Terms and Conditions",variable=check_option,
                               command=check_option_task,onvalue="Yes", offvalue="No")
check_button.pack()



radio_value = tk.StringVar()
def radio_clicked():
    print(radio_value.get())

option1 = ttk.Radiobutton(text="Male", variable=radio_value, value='male', command=radio_clicked)
option2 = ttk.Radiobutton(text="Female", variable=radio_value, value='female', command=radio_clicked)
option1.pack()
option2.pack()







#ComboBox

selected_country = tk.StringVar()
countries = ttk.Combobox(window, textvariable=selected_country, values=('Australia','Sweden','India','United Kingdom','Canada'))
countries['state'] = 'readonly'
countries.pack()

def display_country(event):
    msg = f"Selected Country is : {selected_country.get()}"
    #print(selected_country.get())
    country_label = ttk.Label(window, text=msg)
    country_label.pack()

countries.bind('<<ComboboxSelected>>', display_country)



#LISTBOX

food_items = ('Pizza', 'Burger', "Garlic Bread", "Nachos", " Salad")
fav_food = tk.StringVar(value=food_items)

food_list = tk.Listbox(window, listvariable=fav_food, height=5,selectmode='extended')
food_list.pack()

def get_favorite_food(event):
    food_indices = food_list.curselection()
    for food_index in food_indices:
        food_item = food_list.get(food_index)
        print(food_item)

food_list.bind('<<ListboxSelect>>', get_favorite_food)





#Spinbox
counter = tk.IntVar(value=10)

def get_spin_box_value():
    print(f"current spinbox value is {spin_box.get()}")
#spin_box = ttk.Spinbox(window, from_=0, to=100, increment=1)
#spin_box = ttk.Spinbox(window, values=('0','1','2','3','4','5','6','7'))
spin_box = ttk.Spinbox(window, values=tuple(range(5,105,5)),textvariable=counter, wrap=True, command=get_spin_box_value)
spin_box.pack()

print(f"Initial spinbox value is {spin_box.get()}")





























window.mainloop()