import tkinter as tk

window = tk.Tk()
window.title("Calculator")
window.geometry("600x400")

main_label = tk.Label(window, text="Calculator",font=("Times New Roman", 20, "bold"))
main_label.pack()


#Entry box
display_screen = tk.Entry(window,width=80,borderwidth=3)
display_screen.place(x=100,y=100)
display_screen.pack()


def click(num):
    result = display_screen.get()
    display_screen.delete(0, tk.END)
    display_screen.insert(0, str(result) + str(num))

#buttons
button1 = tk.Button(window, text="1", width=12, height=2, command= lambda : click(1))
button1.place(x=100,y=100)

button2 = tk.Button(window, text="2", width=12, height=2, command= lambda : click(2))
button2.place(x=200,y=100)

button3 = tk.Button(window, text="3", width=12, height=2, command= lambda : click(3))
button3.place(x=300,y=100)

button4 = tk.Button(window, text="4", width=12, height=2, command= lambda : click(4))
button4.place(x=100,y=150)

button5 = tk.Button(window, text="5", width=12, height=2, command= lambda : click(5))
button5.place(x=200,y=150)

button6 = tk.Button(window, text="6", width=12, height=2, command= lambda : click(6))
button6.place(x=300,y=150)

button7 = tk.Button(window, text="7", width=12, height=2, command= lambda : click(7))
button7.place(x=100,y=200)

button8 = tk.Button(window, text="8", width=12, height=2, command= lambda : click(8))
button8.place(x=200,y=200)

button9 = tk.Button(window, text="9", width=12, height=2, command= lambda : click(9))
button9.place(x=300,y=200)

button0 = tk.Button(window, text="0", width=12, height=2, command= lambda : click(0))
button0.place(x=200,y=250)


#OPERATORS



def add():
    n = display_screen.get()
    global math
    math = "addition"
    global i
    i = int(n)
    display_screen.delete(0, tk.END)

add_button = tk.Button(window, text="+", width=12, height=2,command=add)
add_button.place(x=400,y=100)

def sub():
    n = display_screen.get()
    global math
    math = "subtraction"
    global i
    i = int(n)
    display_screen.delete(0, tk.END)

sub_button = tk.Button(window, text="-", width=12, height=2, command=sub)
sub_button.place(x=400,y=150)

def mul():
    n = display_screen.get()
    global math
    math = "multiplication"
    global i
    i = int(n)
    display_screen.delete(0, tk.END)

mul_button = tk.Button(window, text="*", width=12, height=2, command=mul)
mul_button.place(x=400,y=200)

def div():
    n = display_screen.get()
    global math
    math = "division"
    global i
    i = int(n)
    display_screen.delete(0, tk.END)

div_button = tk.Button(window, text="/", width=12, height=2, command=div)
div_button.place(x=400,y=250)

def clear():
    display_screen.delete(0, tk.END)

clear_button = tk.Button(window, text="clear", width=12, height=2,command=clear)
clear_button.place(x=100,y=250)

def equal():
    n2 = display_screen.get()
    display_screen.delete(0, tk.END)

    if math == "addition":
        display_screen.insert(0,i + int(n2))
    elif math == "subtraction":
        display_screen.insert(0,i - int(n2))
    elif math == "multiplication":
        display_screen.insert(0,i * int(n2))
    elif math == "division":
        display_screen.insert(0,i / int(n2))


equal_button = tk.Button(window, text="=", width=12, height=2,command=equal)
equal_button.place(x=300,y=250)




window.mainloop()