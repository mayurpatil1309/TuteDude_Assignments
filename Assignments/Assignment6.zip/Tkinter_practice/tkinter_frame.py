import tkinter as tk
from tkinter import ttk

window=tk.Tk()
#window.minsize(400, 400)

my_frame = ttk.Frame()
my_frame.pack(self='left',fill='both',expand=True)


#label1 = tk.Label(text="Hello World",bg="red")

label1 = tk.Label(my_frame,text="Hello World",bg="red")
label1.pack(side='left',fill='both',expand=True)       #y means vertical y axis
label2 = tk.Label(text="Hello World",bg="green")
label2.pack(side='top',fill='both',expand=True)
label3 = tk.Label(text="Hello World",bg="blue")
label3.pack(side='left',fill='both',expand=True)


window.mainloop()