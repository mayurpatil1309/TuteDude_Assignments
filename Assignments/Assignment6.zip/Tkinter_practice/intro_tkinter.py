import tkinter as tk
from tkinter import font as fnt

window = tk.Tk()
window.title("My Application")
window.minsize(400, 400)

#custom_font = fnt.Font(family="Times New Roman", size=20, weight="bold", slant="italic")
custom_font = fnt.Font(family="Times New Roman", size=20, weight="bold")

#label = tk.Label(text="Hello World", font=("Times New Roman", 20))
label = tk.Label(text="Hello World", font=custom_font)
label.pack()

label["text"] = "Hello World! This is My Application"
'''
counter = 0
def button_clicked():
    global counter
    counter += 1
    label["text"] = f"Hello World! This is My Application\n button clicked on {counter} times"
'''

def button_clicked():
    input_text=user_input.get()
    label["text"] = input_text


user_input = tk.Entry(width=50)
user_input.pack()



#Button
button = tk.Button(text="Click", command=button_clicked)
button.pack()
window.mainloop()